#!/usr/bin/env python
# This script uses a list op IP-adresses of SAProuters connected to the internet and
# run the SAPROUTER -L command against it to see if the configuration is safe

#import the necessary modules
import sys 			#for parsing command line opts
import subprocess	#for running OS command SAPROUTER
import time
import glob
import csv
 
# if file is specified on command line, parse, else ask for file
if sys.argv[1:]:
    print "File: %s" % (sys.argv[1])
    logfile = sys.argv[1]
else:
    logfile = raw_input("Please enter a file with SAProuter IP adresses to parse: ")
 
 
 

# open the file with IP adresses and open a logfile for the output
file = open(logfile, "r")
timestr = time.strftime("%Y%m%d-%H%M%S")
#log = open('log%s.csv' % timestr, 'a')
log = open('log.csv', 'w') 
writer = csv.writer(log)


# read through the file
for text in file.readlines():
   #strip off the \n
    text = text.rstrip()
    print 'trying', text
   #write the IP-adress in the output for reference purposes later as the output only display a resolved hostname normally
#    log.write(text)
   #run sapinfo command and wait for it to finish
#    log.flush()
    try:
        command = "sapinfo.exe ashost=%s sysnr=00" % text
        result = ' '
        result = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        result = result.splitlines()
#        sys.stdout.write(result)
#        writer.writerow(text)
        writer.writerow(text.split()+result)
#        print ','.join(map(str, [i[0] for i in result]))
#       print ','.join(map(str, result))
#        for lines in result:
#            print lines
    except subprocess.CalledProcessError as e:
         writer.writerow(text.split()+['Error reading SAPinfo'])

			
#       process = subprocess.Popen(['sapinfo.exe', 'ashost='+text, 'sysnr=00'], stdout=output, stderr=log, shell=True)
#        ret_code = process.wait()
#       print result
# h   print result
#    log.flush()
#    log.write('_________________________________________________________________________________________________________________________________\n')

		#cleanup and close file
file.close()
	

